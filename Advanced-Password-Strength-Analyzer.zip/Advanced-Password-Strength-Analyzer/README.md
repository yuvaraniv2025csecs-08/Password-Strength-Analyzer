# Advanced Password Strength Analyzer

**Domain:** Cyber Security  
**Language:** Python 3  
**Database:** SQLite

## Project description
An educational command-line project that checks password length and character
variety, flags common patterns, checks whether a password was used previously,
and generates a random password suggestion.

## Features
- Checks minimum length, lowercase, uppercase, digits, and special characters.
- Detects several common words and patterns.
- Checks password reuse against a local SQLite history for the same test username.
- Generates a random password using Python's `secrets` module.
- Stores salted PBKDF2-HMAC-SHA256 hashes rather than plaintext passwords.

## Requirements
- Python 3.8 or later
- No third-party packages required (`sqlite3`, `hashlib`, `secrets`, `re` are part of Python).

## How to run
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

   ```bash
   python password_analyzer.py
   ```

4. Enter a test username and a test password when prompted.

The password input is hidden in a normal terminal. Some IDE consoles may not
support hidden input; if so, run the script from Command Prompt or Terminal.

## Database
The program creates `password_history.db` automatically on first run.
It stores a random salt and a PBKDF2 hash for each saved password, not the
plaintext password. The history is local to this computer and this project
folder. The database is excluded from Git by `.gitignore`.

## Example checks
Try sample test passwords such as:
- `hello`
- `Welcome123`
- `River!Cloud82`

Do not use your real email, banking, or social-media password for testing.

## Limitations
This is a learning project, not a production password manager or authentication
system. The common-pattern list is small, and the score is a basic heuristic.
Password history only works on the computer where the local SQLite database
exists. A strong score does not guarantee that a password has never been
exposed or compromised.

## Author
Add your name here.
